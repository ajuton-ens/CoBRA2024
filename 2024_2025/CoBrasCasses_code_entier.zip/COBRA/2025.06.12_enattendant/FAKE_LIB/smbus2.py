def SMBus(val):
    return val